# SvetLuna — NN Training Animation

Neural Network Training Visualization — an educational Python/Matplotlib demo illustrating decreasing loss, increasing accuracy, and a schematic network representation.

**Author:** Svetlana Romanova — SvetLuna Studio  
**LinkedIn:** https://www.linkedin.com/in/svetlana-romanova-ai

Short description: Visualization of neural network training dynamics through a concise animation showing loss decreasing and accuracy increasing, accompanied by a schematic network illustration. Intended for educational demonstrations and introductory teaching materials.

---

## Contents
- `src/generate_animation.py` — script to generate animation (MP4)
- `example/` — example output (recommended to store video as Release asset, not in repo history)
- `.github/workflows/generate.yml` — optional CI workflow for generating the animation
- `requirements.txt` — dependencies
- `docs/` — documentation and design notes
- `assets/` — preview images and screenshots

## Quick start
```bash
git clone https://github.com/<your-username>/SvetLuna-NN-Animation-Project.git
cd SvetLuna-NN-Animation-Project
python -m venv venv
source venv/bin/activate  # or .\venv\Scripts\Activate.ps1 on Windows
pip install -r requirements.txt
python src/generate_animation.py --frames 35 --fps 1 --out example/nn_training_animation.mp4
```

## Notes on storing video
Avoid committing large binary files into Git history. Use Release assets or Git LFS if needed.

## License
MIT